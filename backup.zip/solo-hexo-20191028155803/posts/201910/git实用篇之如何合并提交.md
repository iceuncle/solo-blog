title: git实用篇之如何合并提交
date: '2019-10-17 18:19:17'
updated: '2019-10-17 18:19:47'
tags: [git]
permalink: /articles/2019/10/17/1571307556955.html
---
有的时候`commit`之后，发现还有`bug`，然后一顿改改改，就又需要提交一次了。这个时候有强迫症的人就觉得不开心了，明明一次功能改动却有了两次改动。或者进行`cherry-pick`的时候也会不方便，本来`cherry-pick`一次就够了，现在却要两次。这个时候就可以进行如下操作。

先把改动都加入暂存区

```js
git add --all
```

再使用如下命令来修改最后一条提交的 commit

```js
git commit --amend
```

然后直接`wq`保存退出vi编辑器，就发现新改动已经合并在上次的提交了。



如果新改动已经提交了呢，比如本来一个功能，却用了三次或者更多次提交来实现了，那也是能合并到一次提交的

```js
首先使用git reset --soft <commit id>
再使用git commit --amend 即可实现
```

使用`git reset --soft <commit id> `可以将某次提交之前的所有修改加入到暂存区

再使用`git commit --amend`修改上一条提交的 `commit`即可实现提交的合并了
