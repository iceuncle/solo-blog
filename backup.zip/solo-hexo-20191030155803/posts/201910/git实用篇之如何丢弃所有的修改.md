title: git实用篇之如何丢弃所有的修改
date: '2019-10-17 18:26:21'
updated: '2019-10-17 18:26:21'
tags: [git]
permalink: /articles/2019/10/17/1571307981199.html
---
大家应该都知道`git checkout .`，但是`git checkout .`只能丢弃非暂存区的修改。如果要把已经加到暂存区的修改也一起丢弃掉呢？

```js
先使用git reset .将所有暂存区的改动都放到非暂存区
再使用git checkout .就可以将所有跟踪文件的修改都丢弃了
```

那么问题来了，`git checkout .`只能丢弃跟踪文件的修改，如果有些非跟踪文件也加进来了应该怎么丢弃呢？

答案是

```js
git clean -df
```




