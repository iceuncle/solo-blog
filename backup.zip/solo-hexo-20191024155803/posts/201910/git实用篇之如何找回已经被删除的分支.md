title: git实用篇之如何找回已经被删除的分支
date: '2019-10-17 18:40:52'
updated: '2019-10-17 18:40:52'
tags: [git]
permalink: /articles/2019/10/17/1571308852025.html
---
找回被删除分支其实在[git进阶篇](https://www.tianyang.pub/articles/2019/10/16/1571240883979.html)中也有所提及，本篇再做一下更详细的介绍。

如果你的分支被误删了，并且远端也被顺手删掉的话（没错，我这么干过。。），那么也不要慌，还是能找回的。

首先通过`git reflog`找到你删除分支的那个提交记录，太多的话，可以通过姓名，提交时间，提交内容等来进行筛选，详细可以看[git进阶篇](https://www.tianyang.pub/articles/2019/10/16/1571240883979.html)

```
在git reflog中找到被最后一次离开被删除分支的commit id
描述类似checkout: moving from remove_branch to master

使用 git checkout -b remove_branch <commit id>即可恢复被删除分支
```


