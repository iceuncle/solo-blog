title: git进阶篇
date: '2019-10-16 23:48:04'
updated: '2019-10-17 00:56:22'
tags: [git]
permalink: /articles/2019/10/16/1571240883979.html
---
### tig

首先介绍下git的命令行工具tig，在同事的安利下使用后，已经可以告别sourceTree了，具体使用方式就不在本篇讲解



### 别名

使用git别名可以简化git命令的敲写，以下是我设置的别名

```js
git config --global alias.st status
git config --global alias.co checkout
git config --global alias.ci commit
git config --global alias.br branch
git config --global alias.cp cherry-pick
```



### cherry-pick

```js
git cherry-pick <commit id>
可以将别的分支的某次提交合并到当前分支
如果有冲突，解决冲突后执行git cherry-pick --continue，可以保留原始提交人和提交时间等信息
放弃cherry-pick执行git cherry-pick --abort
```



### 标签 

```js
添加本地标签
git tag -a 1.1.0 -m “v1.1.0”
推送本地标签至远端
git push origin 1.2.0
删除本地标签
git tag -d 1.1.0
删除远端标签
git push origin :1.2.0
获取远端标签
git fetch 
```



### 子模块

子模块是一个独立的git仓库，可用于多个仓库使用公共模块的场景

**子模块的添加**

```js
git submodule add <url>
```

**子模块的使用**

```js
添加子模块后，需要在项目根目录执行如下命令完成子模块的下载
git submodule init
git submodule update
```

**子模块的更新**

```js
子模块的维护者提交了更新后，使用子模块的项目必须手动更新才能包含最新的提交
方式一 
cd到子模块的目录，执行git pull origin master
方式二 可以一键拉取所有子模块的所有最新代码
git submodule foreach git pull origin master
```



### git log高级用法

**格式化log输出**

```js
git log --oneline
```

**Shortlog**

```js
把每次提交按作者分类，更容易看出谁做了什么
git shortlog
```

**graph**

```js
--graph选项绘制一个ASCII图像来展示提交历史的分支结构。它经常和--oneline一起使用，这样会更容易查看哪个提交属于哪个分支。
git log --graph --oneline
```

**按数量过滤**

```js
显示最近n次的提交
git log -<n>
```

**按日期过滤**

```js
git log --after="2014-7-1"
git log --after="2014-7-1" --before="2014-7-4"
get log --after="yesterday"
```

**按作者过滤**

```js
git log --author="John"
```

**按提交信息**

```js
git log --grep=""
传入-i参数可以忽略大小写匹配
git log -i --grep=""
```

**按文件**

```js
git log -- foo.py bar.py
```

**按内容**

```js
git log -S "Hello, World!"
```

**--all**

```js
加上--all表示搜索所有的分支
git log --all
```

**组合使用**

```js
以上用法可以组合使用，比如在所有分支搜索某次提交的id
git log --all --grep="修复***"
```



### git reflog

reflog是Git操作的一道安全保障，它能够记录几乎所有本地仓库的改变

比如如果你误删了本地分支，并且远端没有备份，就可以通过git reflog找到删除操作的记录id，再通过git checkout -b <id> 来找回 

另外以上git log的所有用法全部适用于git reflog



### rebase

git rebase能够将分叉的分支重新合并

场景一

当本地分支有提交未推送，并且远端分支有提交未拉取时，需要同步的话，就要先pull再push，在执行git pull有冲突的话，git 会自动生成一个merge提交来解决冲突。这时使用git log --graph --oneline来查看提交历史，会发现出现分叉的情况

```js
使用git pull --rebase 解决冲突，可以不会看到分叉
```

场景二

当develop分支和master分支产生冲突时，在master分支执行git merge develop，git同样会自动生成一个merge提交来解决冲突，并且产生分叉

```js
在develop分支 执行
git rebase master 
解决完冲突后执行 git rebase --contine 即可实现提交在一条线上了
再切回master分支，执行merge操作
git checkout master;  git merge develop

git rebase --abort 放弃rebase
```



