title: git基础篇
date: '2019-10-16 08:39:39'
updated: '2019-10-16 22:37:40'
tags: [git]
permalink: /articles/2019/10/16/1571186379322.html
---
### 初始化

```
git init
```

### 关联远程仓库

```js
将本地仓库与远端关联
git remote add origin <仓库地址>
查看远端仓库
git remote -v
解除关联
git remote remove <仓库地址>
```

### 克隆仓库

```
git clone <仓库地址>
```

### 配置信息

```js
git config --global user.name "John Doe"
git config --global user.email johndoe@example.com
列出所有当前配置
git config --list
```

### 获取帮助

```js
git help <verb>
git <verb> --help
```

 ### 查看状态

```
git status
```

### 添加至暂存区

```js
添加一个文件
git add file1.txt
添加多个文件
git add file1.txt file2.txt
添加所有文件(不包括未跟踪文件)
git add .
添加所有文件(包括跟踪文件)
git add --all
```

### 提交暂存区至本地库

```
git commit -m""
```

### 拉取

```
git pull origin <分支名>
```

### 推送

```js
若本地分支未关联远端分支
git push origin -u <分支名>
直接推送到远端关联分支
git push
推动到指定分支
git push origin <分支名>
```

### 分支

```js
创建分支
git branch <分支名>
切换分支(如果本地没有该分支名而远端有，将直接获取远端分支并切换)
git checkout <分支名> 
切换并创建分支
git checkout -b <分支名>
获取远端分支并切换
git checkout -b <分支名> origin <分支名>
查看所有分支和当前分支
git branch
查看本地分支与远端分支
git branch -a
重命名本地分支
git branch -m <oldbranch> <newbranch> //重命名本地分支
```

### 查看与上次提交的不同

```js
某个文件
git diff <file>
所有
git diff
```

### 回退

```js
回退到上个版本
git reset --hard HEAD^ 或者 git reset --hard HEAD~
回退到N个版本之前
git reset --hard HEAD~N
回退到指定提交
git reset --hard <commit id>
```

### 查看提交历史

```
git log
```

### 合并

```
git merge <分支名>
```

### 删除分支

```js
删除本地分支
git branch -d <分支名>
删除远端分支
git push origin :<分支名>
```



